﻿namespace AplicativoComMultiplasJanelas
{
	partial class FormNovoFornecedor
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			groupBox1 = new GroupBox();
			label9 = new Label();
			label8 = new Label();
			label7 = new Label();
			label6 = new Label();
			label5 = new Label();
			label4 = new Label();
			textBoxEnderecoCEP = new TextBox();
			textBoxEnderecoEstado = new TextBox();
			textBoxEnderecoCidade = new TextBox();
			textBoxEnderecoComplemento = new TextBox();
			textBoxEnderecoNumero = new TextBox();
			textBoxEnderecoLogradouro = new TextBox();
			textBoxEmail = new TextBox();
			textBoxTelefone = new TextBox();
			textBoxNomeContato = new TextBox();
			textBoxCNPJ = new TextBox();
			textBoxNomeEmpresa = new TextBox();
			label11 = new Label();
			label3 = new Label();
			label10 = new Label();
			label2 = new Label();
			label1 = new Label();
			buttonCancel = new Button();
			buttonOk = new Button();
			groupBox1.SuspendLayout();
			SuspendLayout();
			// 
			// groupBox1
			// 
			groupBox1.Controls.Add(label9);
			groupBox1.Controls.Add(label8);
			groupBox1.Controls.Add(label7);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(textBoxEnderecoCEP);
			groupBox1.Controls.Add(textBoxEnderecoEstado);
			groupBox1.Controls.Add(textBoxEnderecoCidade);
			groupBox1.Controls.Add(textBoxEnderecoComplemento);
			groupBox1.Controls.Add(textBoxEnderecoNumero);
			groupBox1.Controls.Add(textBoxEnderecoLogradouro);
			groupBox1.Location = new Point(9, 157);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new Size(315, 199);
			groupBox1.TabIndex = 29;
			groupBox1.TabStop = false;
			groupBox1.Text = "Endereço";
			// 
			// label9
			// 
			label9.AutoSize = true;
			label9.Location = new Point(6, 169);
			label9.Name = "label9";
			label9.Size = new Size(31, 15);
			label9.TabIndex = 8;
			label9.Text = "CEP:";
			// 
			// label8
			// 
			label8.AutoSize = true;
			label8.Location = new Point(6, 140);
			label8.Name = "label8";
			label8.Size = new Size(70, 15);
			label8.TabIndex = 8;
			label8.Text = "UF (Estado):";
			// 
			// label7
			// 
			label7.AutoSize = true;
			label7.Location = new Point(6, 111);
			label7.Name = "label7";
			label7.Size = new Size(47, 15);
			label7.TabIndex = 8;
			label7.Text = "Cidade:";
			// 
			// label6
			// 
			label6.AutoSize = true;
			label6.Location = new Point(6, 83);
			label6.Name = "label6";
			label6.Size = new Size(87, 15);
			label6.TabIndex = 8;
			label6.Text = "Complemento:";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Location = new Point(6, 54);
			label5.Name = "label5";
			label5.Size = new Size(54, 15);
			label5.TabIndex = 8;
			label5.Text = "Numero:";
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Location = new Point(6, 25);
			label4.Name = "label4";
			label4.Size = new Size(103, 15);
			label4.TabIndex = 8;
			label4.Text = "Logradouro (Rua):";
			// 
			// textBoxEnderecoCEP
			// 
			textBoxEnderecoCEP.Location = new Point(116, 166);
			textBoxEnderecoCEP.Name = "textBoxEnderecoCEP";
			textBoxEnderecoCEP.Size = new Size(191, 23);
			textBoxEnderecoCEP.TabIndex = 10;
			// 
			// textBoxEnderecoEstado
			// 
			textBoxEnderecoEstado.Location = new Point(116, 137);
			textBoxEnderecoEstado.Name = "textBoxEnderecoEstado";
			textBoxEnderecoEstado.Size = new Size(191, 23);
			textBoxEnderecoEstado.TabIndex = 9;
			// 
			// textBoxEnderecoCidade
			// 
			textBoxEnderecoCidade.Location = new Point(116, 108);
			textBoxEnderecoCidade.Name = "textBoxEnderecoCidade";
			textBoxEnderecoCidade.Size = new Size(191, 23);
			textBoxEnderecoCidade.TabIndex = 8;
			// 
			// textBoxEnderecoComplemento
			// 
			textBoxEnderecoComplemento.Location = new Point(116, 80);
			textBoxEnderecoComplemento.Name = "textBoxEnderecoComplemento";
			textBoxEnderecoComplemento.Size = new Size(191, 23);
			textBoxEnderecoComplemento.TabIndex = 7;
			// 
			// textBoxEnderecoNumero
			// 
			textBoxEnderecoNumero.Location = new Point(116, 51);
			textBoxEnderecoNumero.Name = "textBoxEnderecoNumero";
			textBoxEnderecoNumero.Size = new Size(191, 23);
			textBoxEnderecoNumero.TabIndex = 6;
			// 
			// textBoxEnderecoLogradouro
			// 
			textBoxEnderecoLogradouro.Location = new Point(116, 22);
			textBoxEnderecoLogradouro.Name = "textBoxEnderecoLogradouro";
			textBoxEnderecoLogradouro.Size = new Size(191, 23);
			textBoxEnderecoLogradouro.TabIndex = 5;
			// 
			// textBoxEmail
			// 
			textBoxEmail.Location = new Point(125, 128);
			textBoxEmail.Name = "textBoxEmail";
			textBoxEmail.Size = new Size(199, 23);
			textBoxEmail.TabIndex = 21;
			// 
			// textBoxTelefone
			// 
			textBoxTelefone.Location = new Point(125, 99);
			textBoxTelefone.Name = "textBoxTelefone";
			textBoxTelefone.Size = new Size(199, 23);
			textBoxTelefone.TabIndex = 20;
			// 
			// textBoxNomeContato
			// 
			textBoxNomeContato.Location = new Point(125, 70);
			textBoxNomeContato.Name = "textBoxNomeContato";
			textBoxNomeContato.Size = new Size(199, 23);
			textBoxNomeContato.TabIndex = 19;
			// 
			// textBoxCNPJ
			// 
			textBoxCNPJ.Location = new Point(125, 41);
			textBoxCNPJ.Name = "textBoxCNPJ";
			textBoxCNPJ.Size = new Size(199, 23);
			textBoxCNPJ.TabIndex = 18;
			// 
			// textBoxNomeEmpresa
			// 
			textBoxNomeEmpresa.Location = new Point(125, 12);
			textBoxNomeEmpresa.Name = "textBoxNomeEmpresa";
			textBoxNomeEmpresa.Size = new Size(199, 23);
			textBoxNomeEmpresa.TabIndex = 17;
			// 
			// label11
			// 
			label11.AutoSize = true;
			label11.Location = new Point(9, 73);
			label11.Name = "label11";
			label11.Size = new Size(116, 15);
			label11.TabIndex = 22;
			label11.Text = "Nome para contato: ";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Location = new Point(9, 131);
			label3.Name = "label3";
			label3.Size = new Size(47, 15);
			label3.TabIndex = 27;
			label3.Text = "E-mail: ";
			// 
			// label10
			// 
			label10.AutoSize = true;
			label10.Location = new Point(9, 44);
			label10.Name = "label10";
			label10.Size = new Size(34, 15);
			label10.TabIndex = 23;
			label10.Text = "CNPJ";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Location = new Point(9, 102);
			label2.Name = "label2";
			label2.Size = new Size(57, 15);
			label2.TabIndex = 25;
			label2.Text = "Telefone: ";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(9, 15);
			label1.Name = "label1";
			label1.Size = new Size(107, 15);
			label1.TabIndex = 24;
			label1.Text = "Nome da Empresa:";
			// 
			// buttonCancel
			// 
			buttonCancel.Location = new Point(249, 362);
			buttonCancel.Name = "buttonCancel";
			buttonCancel.Size = new Size(75, 23);
			buttonCancel.TabIndex = 28;
			buttonCancel.Text = "Cancelar";
			buttonCancel.UseVisualStyleBackColor = true;
			// 
			// buttonOk
			// 
			buttonOk.Location = new Point(168, 362);
			buttonOk.Name = "buttonOk";
			buttonOk.Size = new Size(75, 23);
			buttonOk.TabIndex = 26;
			buttonOk.Text = "Ok";
			buttonOk.UseVisualStyleBackColor = true;
			// 
			// FormNovoFornecedor
			// 
			AcceptButton = buttonOk;
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			CancelButton = buttonCancel;
			ClientSize = new Size(336, 397);
			Controls.Add(groupBox1);
			Controls.Add(textBoxEmail);
			Controls.Add(textBoxTelefone);
			Controls.Add(textBoxNomeContato);
			Controls.Add(textBoxCNPJ);
			Controls.Add(textBoxNomeEmpresa);
			Controls.Add(label11);
			Controls.Add(label3);
			Controls.Add(label10);
			Controls.Add(label2);
			Controls.Add(label1);
			Controls.Add(buttonCancel);
			Controls.Add(buttonOk);
			Name = "FormNovoFornecedor";
			Text = "FormNovoFornecedor";
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private GroupBox groupBox1;
		private Label label9;
		private Label label8;
		private Label label7;
		private Label label6;
		private Label label5;
		private Label label4;
		private TextBox textBoxEnderecoCEP;
		private TextBox textBoxEnderecoEstado;
		private TextBox textBoxEnderecoCidade;
		private TextBox textBoxEnderecoComplemento;
		private TextBox textBoxEnderecoNumero;
		private TextBox textBoxEnderecoLogradouro;
		private TextBox textBoxEmail;
		private TextBox textBoxTelefone;
		private TextBox textBoxNomeContato;
		private TextBox textBoxCNPJ;
		private TextBox textBoxNomeEmpresa;
		private Label label11;
		private Label label3;
		private Label label10;
		private Label label2;
		private Label label1;
		private Button buttonCancel;
		private Button buttonOk;
	}
}